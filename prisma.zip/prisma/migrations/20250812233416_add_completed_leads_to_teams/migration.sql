-- AlterTable
ALTER TABLE "teams" ADD COLUMN     "completed_leads" INTEGER NOT NULL DEFAULT 0;
